package com.example.game_01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Medium extends AppCompatActivity {
    private int Score = 0 ;
    private int ScoreEm = 0 ;
    private int UserLP = 20 ;
    private int EmLP = 20 ;
    private int UserAmmor = 0 ;
    private int EmAmmor = 0 ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medium);

        final Button Dicebutton = findViewById(R.id.Dice);
        final Button ATKbutton = findViewById(R.id.ATK);
        final Button DEFbutton = findViewById(R.id.DEF);
        final TextView StatDice = findViewById(R.id.StatDice);
        final TextView StatDiceEm = findViewById(R.id.StatDiceEm);
        final TextView WinorLose = findViewById(R.id.winorlose);
        final TextView STemdice = findViewById(R.id.Dicestem);
        final TextView STdice = findViewById(R.id.Dicest);
        final TextView STAm = findViewById(R.id.Amst);
        final TextView STEMAm = findViewById(R.id.AmEmST);


        //STAm.setText(UserAmmor);
        //STEMAm.setText(EmAmmor);

        Dicebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                int check = 0 ;
                int zero = 0 ;
                int num1 = random.nextInt(6);
                Score += num1;
                STdice.setText("Dice : " + num1);

                if(ScoreEm >= 9){
                    //stop dice Enemy
                }else{
                    // do{
                    check =  random.nextInt(6) ;
                    // }while(ScoreEm + check > 12);
                    if(ScoreEm + check > 12){
                       Score = 0 ;
                        ScoreEm = 0 ;
                       STemdice.setText("Dice : " + zero);
                        STdice.setText("Dice : " + zero);
                        WinorLose.setText("User Win!!");   //if score Enemy > 12 User win ;
                        //delay 2 second

                        //       WinorLose.setText("Win or Lose");
                        //    Reset();
                    }
                    ScoreEm += check ;
                    STemdice.setText("Dice : " + check);
                }
                if(Score > 12 ){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("User Lose!!");
                    //delay 2 second

                    //    WinorLose.setText("Win or Lose");
                    //  Reset();

                }
                StatDice.setText("" + Score);
                StatDiceEm.setText("" + ScoreEm);
            }
        });





        ATKbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int zero = 0 ;
                Random random = new Random();
                int check = 0 ;
                if(ScoreEm < 9){
                    do{
                        check =  random.nextInt(6) ;
                        ScoreEm += check ;
                    }while (ScoreEm < 9) ; //random again till ScoreEM > 9

                    StatDiceEm.setText("" + ScoreEm);
                }

                if(ScoreEm > 12){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("User Win!!");

                }
                ///////////////////////////////////
                ///////////////////////////////////


                ///////////////////////////////////
                ///////////////////////////////////


                if(Score > ScoreEm){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("User Win!!");
                    //delay 2 second

                    //   WinorLose.setText("Win or Lose");
                    //Reset();
                }else if(Score < ScoreEm ){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("User Lose!!");
                    //delay 2 second

                    //   WinorLose.setText("Win or Lose");
                    // Reset();
                }else if(Score == ScoreEm ){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("Draw!!");
                    //delay 2 second

                    // WinorLose.setText("Win or Lose");
                    //Reset();
                }



                Score = 0 ;
                ScoreEm = 0 ;
                StatDice.setText("" + Score);
                StatDiceEm.setText("" + ScoreEm);
            }
        });

        DEFbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int zero = 0 ;
                Random random = new Random();
                int check = 0 ;

                if(Score > ScoreEm){
                    if(ScoreEm > 9){
                        do{
                            check =  random.nextInt(6) ;
                            ScoreEm += check ;
                        }while (ScoreEm < 9) ; //random again till ScoreEM > 9
                    }

                    if(Score > ScoreEm){
                        Score = 0 ;
                        ScoreEm = 0 ;
                        STemdice.setText("Dice : " + zero);
                        STdice.setText("Dice : " + zero);
                        WinorLose.setText("User Win!!");
                    }else{
                        Score = 0 ;
                        ScoreEm = 0 ;
                        STemdice.setText("Dice : " + zero);
                        STdice.setText("Dice : " + zero);
                        WinorLose.setText("User Lose!!");
                    }

                    //delay 2 second

                    //   WinorLose.setText("Win or Lose");
                    //Reset();
                }else if(Score < ScoreEm ){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("User Lose!!");
                    //delay 2 second

                    //   WinorLose.setText("Win or Lose");
                    // Reset();
                }else if(Score == ScoreEm ){
                    Score = 0 ;
                    ScoreEm = 0 ;
                    STemdice.setText("Dice : " + zero);
                    STdice.setText("Dice : " + zero);
                    WinorLose.setText("Draw!!");
                    //delay 2 second

                    // WinorLose.setText("Win or Lose");
                    //Reset();
                }



            }
        });

    }
}